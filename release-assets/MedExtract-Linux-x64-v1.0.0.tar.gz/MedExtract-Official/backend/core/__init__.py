"""
Core module exports
"""

# Only export what we actually use
from .unified_extractor import UnifiedExtractor

__all__ = ['UnifiedExtractor']